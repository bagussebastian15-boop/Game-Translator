# Penerjemah Layar (ScreenTranslator)

Aplikasi penerjemah layar untuk game Android. Memakai engine + OCR dari EmulatorAllInOne (modul `:translate`).

Cara pakai: buka aplikasi > atur bahasa/mesin > Mulai > izinkan "Tampil di atas aplikasi lain" dan rekam layar.
Tombol "A文" melayang muncul: ketuk = terjemahkan layar, ketuk lagi = tutup hasil, seret = pindahkan.

Build: push ke GitHub, workflow `build` menghasilkan APK debug (artifact PenerjemahLayar-debug).

Struktur:
- translate/ : engine terjemahan + OCR (ML Kit), pra-proses gambar, overlay (dari proyek emulator)
- app/       : MainActivity (pengaturan), TranslateService (tombol melayang, MediaProjection, overlay)

## Build lewat GitHub (cukup dari HP)
1. Buat repo baru di GitHub, upload ISI folder proyek (settings.gradle.kts, app/, translate/, dst).
   Folder tersembunyi `.github` sulit diunggah dari HP: pakai "Add file > Create new file", ketik nama
   `.github/workflows/build.yml`, lalu tempel isi file build.yml.
2. Tab Actions > build > tunggu selesai (sekitar 5-10 menit) > unduh artifact `PenerjemahLayar`.
3. Pilih APK sesuai HP: **armeabi-v7a** (cocok untuk SEMUA HP ARM, termasuk Android 5 jadul - pilih ini bila ragu)
   atau **arm64-v8a** (HP 64-bit, sedikit lebih cepat).
4. Opsional: buat tag `v1.0` agar APK muncul di tab Releases.

## Android 5 dan ringan
- minSdk 21 (Android 5.0). APK dipisah per CPU, tanpa x86.
- Model OCR memakai ML Kit versi Play Services (tidak ikut di APK). HP perlu Google Play Services.
- Release dikecilkan dengan R8 dan shrinkResources.
