package com.screentranslator.app

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("st", Context.MODE_PRIVATE)
    var source: String get() = sp.getString("source", "auto")!!; set(v) = sp.edit().putString("source", v).apply()
    var online: Boolean get() = sp.getBoolean("online", true); set(v) = sp.edit().putBoolean("online", v).apply()
    var onlineEngine: Int get() = sp.getInt("onlineEngine", 0); set(v) = sp.edit().putInt("onlineEngine", v).apply()
    var groqKey: String get() = sp.getString("groqKey", "")!!; set(v) = sp.edit().putString("groqKey", v).apply()
    var groqModel: String get() = sp.getString("groqModel", "")!!; set(v) = sp.edit().putString("groqModel", v).apply()
    var menuMode: Boolean get() = sp.getBoolean("menuMode", false); set(v) = sp.edit().putBoolean("menuMode", v).apply()
    var bottomOnly: Boolean get() = sp.getBoolean("bottomOnly", false); set(v) = sp.edit().putBoolean("bottomOnly", v).apply()
    var thorough: Boolean get() = sp.getBoolean("thorough", false); set(v) = sp.edit().putBoolean("thorough", v).apply()
}
