package com.screentranslator.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.allinone.emulator.translate.TranslationEngine
import com.allinone.emulator.translate.TranslationOverlayView
import kotlinx.coroutines.*
import java.io.File
import kotlin.math.abs

/**
 * Layanan latar depan: tombol melayang + tangkap layar (MediaProjection) + engine OCR/terjemahan,
 * hasilnya digambar TranslationOverlayView di jendela overlay layar penuh yang tidak bisa disentuh.
 */
class TranslateService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val lock = Any()
    private var latest: Image? = null
    @Volatile private var frameSeq = 0
    private var sw = 0
    private var sh = 0
    private var dpi = 0

    private lateinit var overlay: TranslationOverlayView
    private lateinit var overlayLp: WindowManager.LayoutParams
    private lateinit var button: TextView
    private lateinit var buttonLp: WindowManager.LayoutParams
    private val engine = TranslationEngine()
    private var freezeView: ImageView? = null
    private var freezeBmp: Bitmap? = null
    private var busy = false
    private var hasResult = false

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE      // Android 5-7

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_NOT_STICKY
        val data = intent?.getParcelableExtra<Intent>("data")
        val code = intent?.getIntExtra("code", 0) ?: 0
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        startAsForeground()          // wajib sebelum getMediaProjection (Android 14)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        readScreenSize()
        setupCapture()
        setupViews()
        return START_NOT_STICKY
    }

    // ---------- foreground ----------
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        @Suppress("DEPRECATION")
        val nb = if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("st", "Penerjemah Layar", NotificationManager.IMPORTANCE_LOW))
            Notification.Builder(this, "st")
        } else Notification.Builder(this)
        val n = nb
            .setContentTitle("Penerjemah Layar aktif")
            .setContentText("Ketuk tombol melayang untuk menerjemahkan. Buka aplikasi lalu Berhenti untuk menutup.")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- tangkap layar ----------
    @Suppress("DEPRECATION")
    private fun readScreenSize() {
        val dm = resources.displayMetrics
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            sw = b.width(); sh = b.height()
        } else {
            val p = android.graphics.Point()
            wm.defaultDisplay.getRealSize(p)
            sw = p.x; sh = p.y
        }
        dpi = dm.densityDpi
    }

    private fun setupCapture() {
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) { latest?.close(); latest = img; frameSeq++ }
        }, main)
        reader?.close()
        reader = r
        val d = display
        if (d == null) {
            display = projection!!.createVirtualDisplay(
                "st", sw, sh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, main
            )
        } else {
            d.resize(sw, sh, dpi)
            d.surface = r.surface
        }
    }

    private fun latestBitmap(): Bitmap? = synchronized(lock) {
        val img = latest ?: return null
        val plane = img.planes[0]
        val rowPad = plane.rowStride - plane.pixelStride * img.width
        val bw = img.width + rowPad / plane.pixelStride
        val raw = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(plane.buffer)
        if (bw == img.width) raw else Bitmap.createBitmap(raw, 0, 0, img.width, img.height).also { raw.recycle() }
    }

    // ---------- tampilan ----------
    private fun setupViews() {
        overlay = TranslationOverlayView(this)
        overlayLp = WindowManager.LayoutParams(
            sw, sh, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
        wm.addView(overlay, overlayLp)

        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        button = TextView(this).apply {
            text = "A文"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC2962FF.toInt()) }
            alpha = 0.85f
        }
        buttonLp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = sh / 3 }
        wm.addView(button, buttonLp)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        button.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = buttonLp.x; startY = buttonLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > 12 || abs(e.rawY - downY) > 12) moved = true
                    if (moved) {
                        buttonLp.x = startX + (e.rawX - downX).toInt()
                        buttonLp.y = startY + (e.rawY - downY).toInt()
                        wm.updateViewLayout(button, buttonLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap()
            }
            true
        }
    }

    // ---------- bekukan layar ----------
    private fun showFreeze(frame: Bitmap) {
        hideFreeze()
        val copy = frame.copy(Bitmap.Config.ARGB_8888, false) ?: return
        freezeBmp = copy
        val iv = ImageView(this).apply {
            setImageBitmap(copy)
            scaleType = ImageView.ScaleType.FIT_XY
            setOnTouchListener { _, _ -> true }      // sentuhan tidak sampai ke game
            isFocusableInTouchMode = true
            setOnKeyListener { _, k, e ->            // tombol Kembali = tutup hasil
                if (k == android.view.KeyEvent.KEYCODE_BACK && e.action == android.view.KeyEvent.ACTION_UP) { dismissResult(); true } else false
            }
        }
        val lp = WindowManager.LayoutParams(
            sw, sh, overlayType(),
            // TANPA FLAG_NOT_FOCUSABLE: jendela ini mengambil fokus dari game, sehingga emulator
            // yang berhenti saat kehilangan fokus ikut jeda sungguhan.
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
        try {
            wm.addView(iv, lp)
            // taruh di bawah overlay terjemahan & tombol: lepas lalu pasang ulang keduanya di atasnya
            wm.removeView(overlay); wm.addView(overlay, overlayLp)
            wm.removeView(button); wm.addView(button, buttonLp)
            freezeView = iv
            iv.requestFocus()
            pauseGame()
        } catch (e: Exception) { runCatching { wm.removeView(iv) } }
    }

    // Naikkan Activity hitam ke depan game -> game menerima onPause -> emulator jeda sungguhan.
    private fun pauseGame() {
        FreezeActivity.onClosed = { main.post { if (hasResult || freezeView != null) dismissResult() } }
        try {
            startActivity(Intent(this, FreezeActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS))
        } catch (e: Exception) { /* tetap beku secara tampilan */ }
    }

    private fun hideFreeze() {
        FreezeActivity.onClosed = null
        FreezeActivity.current?.finish()
        freezeView?.let { runCatching { wm.removeView(it) } }
        freezeView = null
        freezeBmp = null
    }

    private fun dismissResult() { overlay.clear(); hasResult = false; hideFreeze() }

    private fun onTap() {
        if (busy) return
        if (hasResult) { dismissResult(); return }
        translateNow()
    }

    private fun translateNow() {
        busy = true
        button.text = "…"
        scope.launch {
            var frame: Bitmap? = null
            try {
                // sembunyikan overlay + tombol supaya tidak ikut terekam
                overlay.visibility = View.INVISIBLE
                button.visibility = View.INVISIBLE
                val seq = frameSeq
                var waited = 0
                while (frameSeq == seq && waited < 250) { delay(8); waited += 8 }   // tunggu frame baru tanpa tombol
                frame = withContext(Dispatchers.Default) { latestBitmap() }
                if (frame != null && prefs.freeze) showFreeze(frame)     // beku seketika
                button.visibility = View.VISIBLE
                overlay.visibility = View.VISIBLE
                if (frame == null) { toast("Belum ada gambar layar. Coba lagi."); return@launch }

                engine.online = prefs.online
                engine.onlineEngine = prefs.onlineEngine
                engine.groqKey = prefs.groqKey
                engine.groqModel = prefs.groqModel.ifBlank { TranslationEngine.GROQ_DEFAULT_MODEL }
                engine.menuMode = prefs.menuMode
                engine.glyphFile = File(filesDir, "glyphs.bin")

                val result = engine.run(frame, prefs.source, prefs.bottomOnly, prefs.thorough, null, null) { s ->
                    if (s.isNotBlank()) toast(s)
                }
                when {
                    result == null -> toast("Teks tidak terbaca ${engine.debugSummary()}")
                    result.blocks.none { it.box != null } -> toast("Tidak ada teks yang perlu diterjemahkan.")
                    else -> {
                        overlay.show(result.blocks, result.frameW, result.frameH, 0f, 0f)
                        hasResult = true
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("Gagal: ${e.message ?: e.javaClass.simpleName}" +
                    if (!prefs.online) ". Model offline diunduh sekali saat pertama dipakai (butuh internet)." else "")
            } finally {
                button.visibility = View.VISIBLE
                overlay.visibility = View.VISIBLE
                frame?.let { if (!it.isRecycled) it.recycle() }
                if (!hasResult) hideFreeze()
                button.text = "A文"
                busy = false
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (projection == null) return
        overlay.clear(); hasResult = false; hideFreeze()
        readScreenSize()
        synchronized(lock) { latest?.close(); latest = null }
        setupCapture()
        overlayLp.width = sw; overlayLp.height = sh
        wm.updateViewLayout(overlay, overlayLp)
    }

    override fun onDestroy() {
        scope.cancel()
        hideFreeze()
        runCatching { wm.removeView(button) }
        runCatching { wm.removeView(overlay) }
        synchronized(lock) { latest?.close(); latest = null }
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        engine.close()
        super.onDestroy()
    }
}
