package com.screentranslator.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import com.allinone.emulator.translate.TranslationEngine

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private val REQ_CAPTURE = 1
    private val REQ_NOTIF = 2

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad / 2, 0, 0) }.also { col.addView(it) }
        fun sw(t: String, v: Boolean, on: (Boolean) -> Unit) = Switch(this).apply {
            text = t; isChecked = v; setOnCheckedChangeListener { _, c -> on(c) }
        }.also { col.addView(it) }
        fun spinner(items: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = on(pos)
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }.also { col.addView(it) }

        col.addView(TextView(this).apply { text = "Penerjemah Layar"; textSize = 24f })

        label("Bahasa teks di layar")
        val keys = TranslationEngine.SOURCES.map { it.first }
        spinner(TranslationEngine.SOURCES.map { it.second }, keys.indexOf(prefs.source).coerceAtLeast(0)) { prefs.source = keys[it] }

        sw("Mode online (Google/Groq). Mati = offline ML Kit", prefs.online) { prefs.online = it }
        label("Mesin online")
        spinner(listOf("Google Translate", "Groq (LLM, butuh kunci API)"), prefs.onlineEngine) { prefs.onlineEngine = it }
        label("Kunci API Groq (opsional)")
        col.addView(EditText(this).apply {
            setText(prefs.groqKey); hint = "gsk_..."
            setOnFocusChangeListener { _, f -> if (!f) prefs.groqKey = text.toString().trim() }
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { prefs.groqKey = s.toString().trim() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        })
        sw("Mode menu (terjemahkan semua tulisan menu)", prefs.menuMode) { prefs.menuMode = it }
        sw("Hanya baca bagian bawah layar (dialog)", prefs.bottomOnly) { prefs.bottomOnly = it }
        sw("Teliti (lebih lambat, lebih akurat)", prefs.thorough) { prefs.thorough = it }

        col.addView(Button(this).apply {
            text = "Mulai"
            setOnClickListener { start() }
        })
        col.addView(Button(this).apply {
            text = "Berhenti"
            setOnClickListener { stopService(Intent(this@MainActivity, TranslateService::class.java)) }
        })
        col.addView(TextView(this).apply {
            text = "Setelah Mulai, tombol melayang muncul di atas game. Ketuk untuk menerjemahkan layar; ketuk lagi untuk menutup hasil. Seret untuk memindahkan."
            setPadding(0, pad, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun start() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {   // Android 5: izin otomatis
            Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain', lalu tekan Mulai lagi.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (c == REQ_NOTIF) start()      // lanjut walau notifikasi ditolak
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                val i = Intent(this, TranslateService::class.java).putExtra("code", res).putExtra("data", data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                moveTaskToBack(true)
            } else Toast.makeText(this, "Izin rekam layar ditolak.", Toast.LENGTH_SHORT).show()
        }
    }
}
