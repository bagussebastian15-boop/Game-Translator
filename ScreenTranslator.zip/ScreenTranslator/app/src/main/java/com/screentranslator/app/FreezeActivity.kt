package com.screentranslator.app

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager

/**
 * Activity hitam penuh layar yang sengaja naik ke depan game. Akibatnya Activity game menerima onPause,
 * sehingga emulator/game yang menjeda diri saat tidak di depan benar-benar berhenti.
 * Yang terlihat oleh pemain tetap gambar beku (jendela overlay di atasnya); Activity ini hanya penjeda.
 */
class FreezeActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        current = this
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        setContentView(View(this).apply {
            setBackgroundColor(Color.BLACK)
            systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        })
    }

    override fun onBackPressed() = finish()

    override fun onDestroy() {
        if (current === this) current = null
        onClosed?.invoke()
        super.onDestroy()
    }

    companion object {
        @Volatile var current: FreezeActivity? = null
        @Volatile var onClosed: (() -> Unit)? = null
    }
}
