plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.screentranslator.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.screentranslator.app"
        minSdk = 21            // Android 5.0
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    // APK terpisah per CPU -> masing-masing jauh lebih kecil (tanpa x86 & tanpa ABI lain)
    splits {
        abi {
            isEnable = true
            reset()
            include("armeabi-v7a", "arm64-v8a")
            isUniversalApk = false
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    buildTypes {
        release {
            isMinifyEnabled = true          // R8: kecilkan kode
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")   // supaya APK release bisa langsung dipasang
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":translate"))
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
